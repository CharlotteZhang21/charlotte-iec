// overide old inline (non-iframe) way of calling SDK
window.callSDK = function() {
    parent.postMessage('download', '*');
};

// overide old inline (non-iframe) way of calling SDK
window.actionClicked = function() {
    parent.postMessage('download', '*');
};

// overide adwords open event
window.open = function() {
    parent.postMessage('download', '*');
};